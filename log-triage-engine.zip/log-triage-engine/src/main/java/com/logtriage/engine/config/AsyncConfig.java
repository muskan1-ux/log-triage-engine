package com.logtriage.engine.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
public class AsyncConfig {

    /**
     * Bounded pool that isolates LLM-backed triage work from the Kafka consumer threads.
     * AbortPolicy is deliberate: when saturated we want a RejectedExecutionException we can
     * translate into a RetryableProcessingException, so the Kafka error handler backs off
     * instead of silently blocking (CallerRunsPolicy) or dropping work (DiscardPolicy).
     */
    @Bean(name = "triageExecutor")
    public Executor triageExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(8);
        executor.setMaxPoolSize(32);
        executor.setQueueCapacity(500);
        executor.setThreadNamePrefix("log-triage-");
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();
        return executor;
    }
}
