package com.logtriage.engine.exception;

/**
 * Signals a transient failure (executor saturation, DB connection blip, Redis timeout).
 * The Kafka {@code DefaultErrorHandler} will retry with backoff before routing to the DLQ.
 */
public class RetryableProcessingException extends LogProcessingException {
    public RetryableProcessingException(String message) {
        super(message);
    }

    public RetryableProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
