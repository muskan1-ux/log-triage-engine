package com.logtriage.engine.service;

import com.logtriage.engine.exception.RetryableProcessingException;
import com.logtriage.engine.model.LogEvent;
import com.logtriage.engine.producer.DlqProducer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;

/**
 * Entry point invoked by the Kafka listener for every non-duplicate record.
 *
 * Design trade-off worth calling out explicitly: INFO/WARN events are persisted
 * synchronously (cheap), but ERROR/FATAL events are handed off to a bounded executor
 * and the Kafka offset is committed as soon as the hand-off succeeds - not after the LLM
 * triage and DB write finish. This keeps the consumer poll loop fast and avoids blocking
 * partition throughput on slow LLM calls. It also means a crash between "handed off" and
 * "triage persisted" can lose an in-flight triage; Redis-backed deduplication on replay
 * absorbs most of that risk. If you need stronger guarantees than at-least-once-with-a-gap,
 * switch the container's AckMode to MANUAL and ack only after saveWithTriage() returns -
 * at the cost of consumer throughput.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LogProcessingService {

    private final DeduplicationService deduplicationService;
    private final LogTriageOrchestrator triageOrchestrator;
    private final LogPersistenceService persistenceService;
    private final DlqProducer dlqProducer;

    @Qualifier("triageExecutor")
    private final Executor triageExecutor;

    public void handle(LogEvent event) {
        if (deduplicationService.isDuplicate(event)) {
            log.debug("Duplicate event {} skipped", event.eventId());
            return;
        }

        if (event.level().requiresTriage()) {
            dispatchForTriage(event);
        } else {
            persistenceService.saveRaw(event);
        }
    }

    private void dispatchForTriage(LogEvent event) {
        try {
            triageExecutor.execute(() -> runTriage(event));
        } catch (RejectedExecutionException rex) {
            // Executor is saturated: surface a retryable exception so the Kafka error handler
            // backs off and retries rather than silently dropping the record.
            throw new RetryableProcessingException(
                    "Triage executor saturated for event " + event.eventId(), rex);
        }
    }

    private void runTriage(LogEvent event) {
        triageOrchestrator.triageAsync(event)
                .thenAccept(result -> persistenceService.saveWithTriage(event, result))
                .exceptionally(ex -> {
                    log.error("Unrecoverable triage failure for event {}", event.eventId(), ex);
                    dlqProducer.send(event, ex);
                    return null;
                });
    }
}
