package com.logtriage.engine.exception;

/**
 * Signals a permanent failure (malformed payload, validation failure, poison message).
 * The Kafka {@code DefaultErrorHandler} skips retries and publishes straight to the DLQ.
 */
public class NonRetryableProcessingException extends LogProcessingException {
    public NonRetryableProcessingException(String message) {
        super(message);
    }

    public NonRetryableProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
