package com.logtriage.engine.model;

import java.time.Instant;

/** Envelope published to the DLQ topic so failed events can be inspected and replayed. */
public record DlqRecord(
        LogEvent originalEvent,
        String exceptionType,
        String exceptionMessage,
        Instant failedAt
) {}
